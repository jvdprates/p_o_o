#include "Amigo.h"

string Amigo::getAniversario() const{
    return this->aniversario;
};

void Amigo::setAniversario(string s){
    this->aniversario = s;
};