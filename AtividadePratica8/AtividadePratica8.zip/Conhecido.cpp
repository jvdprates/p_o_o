#include "Conhecido.h"

string Conhecido::getEmail() const{
    return this->email;
};

void Conhecido::setEmail(string s){
    this->email = s;
};